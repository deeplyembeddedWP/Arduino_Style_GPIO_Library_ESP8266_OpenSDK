#ifndef __USER_MYCONFIG_H__
#define __USER_MYCONFIG_H__

#include "c_types.h"
#include "eagle_soc.h"
#include "ets_sys.h"
#include "user_esp8266_peri.h"
#include "user_GPIO_Config.h"


//extern const uint8_t SPI_MODE0;///<  CPOL: 0  CPHA: 0
//extern const uint8_t SPI_MODE1;///<  CPOL: 0  CPHA: 1
//extern const uint8_t SPI_MODE2;///<  CPOL: 1  CPHA: 0
//extern const uint8_t SPI_MODE3;///<  CPOL: 1  CPHA: 1

#endif
