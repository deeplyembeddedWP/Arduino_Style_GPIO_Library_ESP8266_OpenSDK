#include "ets_sys.h"
#include "osapi.h"
#include "gpio.h"
#include "os_type.h"
#include "user_MyConf.h"

/* Definitions */
#define GPIO_PIN_4	4

/* Timer to blink LED every 100ms */
volatile os_timer_t My_timer;

void
user_rf_pre_init (void)
{
}


/*****************************************************************
 * Function Name                :       blink_led
 * Description                  :       Function to blink LED
 *                              	every 100 ms
 * Returns                      :       NONE.
 * Params                       :       NONE.
 ****************************************************************/
void ICACHE_FLASH_ATTR
blink_led ()
{
  /* Local static to check GPIO pin status */
  static int gpio_val = 0;

  /* Read the current status of the pin */
  gpio_val = digitalRead (GPIO_PIN_4);

  /* Check the status of the pin */
  if (gpio_val)
    digitalWrite (GPIO_PIN_4, LOW);
  else
    digitalWrite (GPIO_PIN_4, HIGH);

}

/*Init function*/
void ICACHE_FLASH_ATTR
user_init ()
{
  /* Initialize the GPIO_4 */
  pinMode (GPIO_PIN_4, OUTPUT);
  digitalWrite (GPIO_PIN_4, LOW);

  /*setup timer (100ms, repeating) */
  os_timer_setfn (&My_timer, (os_timer_func_t *) blink_led, NULL);
  os_timer_arm (&My_timer, 100, 1);
}
